package main;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1 = new User();
//		System.out.println(u1.getloginID("a_moiz", "54321"));
		u1.getUserData("3");
	}

}
